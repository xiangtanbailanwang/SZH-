#ifndef __PID_H
#define __PID_H

#include "stm32f10x.h"                  // Device header

typedef struct
{
	float KP,KI,KD;
	float error,last_error;
	float intergal,max_intergal;
	float Output,max_Output;
	
}PID_Param;

void PID_Init(PID_Param *MYPID,float KP,float KI,float KD,float max_intergal,float max_Output);
void PID_caculate(PID_Param *MYPID,float reference,float feedback);




#endif

