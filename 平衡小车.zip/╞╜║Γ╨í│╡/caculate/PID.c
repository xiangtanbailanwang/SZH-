#include "stm32f10x.h"                  // Device header

typedef struct
{
	float KP,KI,KD;
	float error,last_error;
	float intergal,max_intergal;
	float Output,max_Output;
	
}PID_Param;


void PID_Init(PID_Param *MYPID,float KP,float KI,float KD,float max_intergal,float max_Output)
{

	MYPID->KP=KP;
	MYPID->KI=KI;
	MYPID->KD=KD;
	MYPID->max_intergal=max_intergal;
	MYPID->max_Output=max_Output;

}


void PID_caculate(PID_Param *MYPID,float reference,float feedback)
{	
	MYPID->last_error=MYPID->error; 
	MYPID->error=reference-feedback;
	float dout=(MYPID->error-MYPID->last_error)*MYPID->KD;
	float pout=MYPID->error*MYPID->KP;
	MYPID->intergal=MYPID->intergal+MYPID->error*MYPID->KI;
	
	if(MYPID->intergal>=MYPID->max_intergal)
	{
		MYPID->intergal=MYPID->max_intergal;
	}
	else if(MYPID->intergal<=-MYPID->max_intergal)
	{
		MYPID->intergal=-MYPID->max_intergal;
	}
	
	MYPID->Output=MYPID->intergal+pout+dout;		//�������
	
	if(MYPID->Output>=MYPID->max_Output)
	{
		MYPID->Output=MYPID->max_Output;
	}
	else if(MYPID->Output<=-MYPID->max_Output)
	{
		MYPID->Output=-MYPID->max_Output;
	}
}










