/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * Description : ����һ��ƽ��С�����루������
  *  
  ******************************************************************************
  * @attention
  *
	*						  	  		   _ooOoo_
	*							  		    o8888888o
	*							  	  	  88" . "88
	*							  	  	  (| -_- |)
	*							    		  O\  =  /O
  *							  	   ____/`---'\____
  *							  	 .'  \\|     |//  `.
  *						  		/  \\|||  :  |||//  \
  *							   /  _||||| -:- |||||-  \
  *							   |   | \\\  -  /// |   |
  *							   | \_|  ''\-/''    |   |
  *							   \  .-\__  `-`  ___/-. /
  *							 ___`. .'  /-.-\  `. . __
  *						  ."" '<  `.___\_<|>_/___.'  >'"".
  *						 | | :  `- \`.;`\ _ /`;.`/ - ` : | |
  *						 \  \ `-.   \_ __\ /__ _/   .-` /  /
  *				======`-.____`-.___\_____/___.-`____.-'======
  *										`=-='
  *
  *					 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  *                 ���汣��        ����BUG
  *	
  ******************************************************************************
  */
/*  USER CODE END Header */
/*

attention:
		motor1							motor2
		left								right
		TIM1_OC1						TIM1_OC4
		TIM3_IC12						TIM2_IC12			
DEATH AREO:
		100									100
PID_SPEED AREO:
		0-800								0-800
		
*/

#include "share_bank.h"

short gyrox,gyroy,gyroz,aacx,aacy,aacz;
float Pitch,Roll,Yaw;	


int main()
{	
	serial_init();
	MOTOR_INIT();
	ENCODER_INIT();
	OLED_Init();	
	NVIC_Configuration();
	MPU_Init();
	mpu_dmp_init();
	MPU6050_EXTI_Init();
//	motor1_set_speed(100);


	while(1)
	{
		OLED_ShowSignedNum(1,1,Pitch,2);
		OLED_ShowChar(1,4,'.');
		OLED_ShowNum(1,5,Pitch*10,1);
		OLED_ShowSignedNum(2,1,gyroy,4);
		OLED_ShowSignedNum(3,1,gyroz,4);
		OLED_ShowSignedNum(4,1,MOTOR1,4);
		OLED_ShowSignedNum(4,7,MOTOR2,4);
		
	}


}



