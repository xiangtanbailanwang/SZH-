/***************************************************

		������
		
***************************************************/


#include "stm32f10x.h"                  // Device header
#include "MOTOR.h"
#include "OLED.h"
#include "ENCODER.h"
#include "DELAY.h"
#include "PWM.H"
#include "TIMER.h"
#include "pid.h"
#include "MOVE_ACTION.h"
#include "MPU6050_EXTI.h"
#include "Balance_pid.h"
#include "mpu6050.h"
#include "mpuiic.h"
#include "dmpKey.h"
#include "dmpmap.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include "stdlib.h"
#include "control.h"
#include "SERIAL.h"

#define delay_ms(n)		Delay_ms(n)
#define delay_us(n)		Delay_us(n)
#define  death_line  22

extern short gyrox,gyroy,gyroz,aacx,aacy,aacz;		//������ 	���ٶ�
extern float Pitch,Roll,Yaw;	
