#ifndef __BALANCE_PID_H
#define __BALANCE_PID_H

#include "stm32f10x.h"                  // Device header

extern float Mid_angle;						//�����ǻ�е��㣺-8.0  �����1.5��										
extern float Vertical_kp;
extern float Vertical_kD;
extern float Velocity_kp;
extern float Velocity_kI;
extern float Expect_Velocity;					//ָ���ٶ�
extern float a;
extern float aim_turn;

extern float AIM_Angle;
extern int16_t motor1_out,motor2_out;

int16_t Vertical_pid(float Pitch,float aim_angle,short gyroy);
float Velocity_pid(float encoder_speed1,float encoder_speed2,float Expect_Velocity);		//���ҵ���ٶ�
int16_t Turn(int gyroz,float aim_turn);



#endif

