#ifndef __SERIAL_H
#define __SERIAL_H
#include "stm32f10x.h"                  // Device header

extern uint8_t Serial_Rxflag;
extern uint8_t Serial_Rxdata;

extern int8_t rxdata[5];
extern uint8_t parity_byte;
extern uint8_t byte_serial_number;

void serial_init(void);
void SERIAL_SENT_BIT(uint8_t byte);
void SERIAL_SENT_MY_ARRY(uint8_t *arry);
void SERIAL_SENT_STRING(char *mystr);
void SERIAL_SENT_NUMBER(uint32_t NUMBER,uint8_t LENGTH);
void serial_printf(char *format,...);
uint8_t serial_getrxflage(void);
uint8_t serial_getrxdata(void);

void USART1_IRQHandler(void);

#endif


