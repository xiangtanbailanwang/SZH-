#ifndef __MOVE_ACTION_H
#define __MOVE_ACTION_H
#include "stm32f10x.h"                  // Device header

extern PID_Param motor1_pid;
extern PID_Param motor2_pid;

extern int16_t motor1_speed;			//���õ���ٶ�
extern int16_t motor2_speed;

void pid_speed_init();
void pid_speed_control(int16_t speed1,int16_t speed2);

#endif
