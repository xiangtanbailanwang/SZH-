#ifndef __MPU6050_EXTI_H
#define __MPU6050_EXTI_H
#include "stm32f10x.h"                  // Device header

void MPU6050_EXTI_Init(void);
void NVIC_Configuration(void);

#endif

