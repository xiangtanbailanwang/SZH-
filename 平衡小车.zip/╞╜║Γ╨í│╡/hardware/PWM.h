#ifndef __PWM_H
#define __PWM_H
#include "stm32f10x.h"                  // Device header

void PWM_INIT(void);
void pwm_setcompare1(uint16_t compare);
void pwm_setcompare4(uint16_t compare);
#endif
