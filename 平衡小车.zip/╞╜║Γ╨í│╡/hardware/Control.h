#ifndef __CONTROL_H
#define __CONTROL_H

#include "share_bank.h"


extern float vertical_out,velocity_out,turn_out;
extern int16_t MOTOR1,MOTOR2;
void EXTI9_5_IRQHandler(void);
void pwm_limit(int16_t* MOTOR);
void pwm_death_area1(int16_t* MOTOR);		//��������
void pwm_death_area2(int16_t* MOTOR);		//��������
#endif

