/************************************************************************

电机转向控制函数，这里不做解释了

************************************************************************/
#include "share_bank.h"

/*************************************************************************************/

void MOTOR_INIT(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);

	GPIO_InitTypeDef gpio_init_structure;
	gpio_init_structure.GPIO_Mode=GPIO_Mode_Out_PP;			//这里必须用out
	gpio_init_structure.GPIO_Pin=GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_2|GPIO_Pin_3;
	gpio_init_structure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio_init_structure);
	
//	gpio_init_structure.GPIO_Pin=GPIO_Pin_0;
//	GPIO_Init(GPIOB,&gpio_init_structure);
	
	PWM_INIT();
}

/*************************************************************************************/

void motor1_set_speed(int16_t speed)
{
	if(speed>=0)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_5);
		GPIO_ResetBits(GPIOA,GPIO_Pin_4);
		pwm_setcompare1(speed);
	}
	else 
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_5);
		GPIO_SetBits(GPIOA,GPIO_Pin_4);
		pwm_setcompare1(-speed);
	
	}
	
}

void motor2_set_speed(int16_t speed)
{
	if(speed>=0)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_2);
		GPIO_ResetBits(GPIOA,GPIO_Pin_3);
		pwm_setcompare4(speed);
	}
	else 
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_2);
		GPIO_SetBits(GPIOA,GPIO_Pin_3);
		pwm_setcompare4(-speed);
	
	}
	
}

/*************************************************************************************/















