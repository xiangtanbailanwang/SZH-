#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>
#include "share_bank.h"
uint8_t Serial_Rxflag;
uint8_t Serial_Rxdata;

int8_t rxdata[5];
uint8_t parity_byte;
uint8_t byte_serial_number;


void serial_init(void)					//USART1初始化函数
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	
	/*****************************************************************************************/
	//初始化串口通行引脚
	
	GPIO_InitTypeDef gpio_init_structure;
	gpio_init_structure.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio_init_structure.GPIO_Pin=GPIO_Pin_9;
	gpio_init_structure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio_init_structure);

	gpio_init_structure.GPIO_Mode=GPIO_Mode_IPU;
	gpio_init_structure.GPIO_Pin=GPIO_Pin_10;
	gpio_init_structure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio_init_structure);

	
	/*****************************************************************************************/
	//初始化usart1串口

	USART_InitTypeDef usart_init_structure;
	usart_init_structure.USART_BaudRate=9600;
	usart_init_structure.USART_HardwareFlowControl=DISABLE;
	usart_init_structure.USART_Mode=USART_Mode_Rx;
	usart_init_structure.USART_Parity=USART_Parity_No;
	usart_init_structure.USART_StopBits=USART_StopBits_1;
	usart_init_structure.USART_WordLength=USART_WordLength_8b;
	
	
	/*****************************************************************************************/
	
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);		//启用或禁用usart相应中断
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef nvic_init_structure;
	nvic_init_structure.NVIC_IRQChannel=USART1_IRQn;
	nvic_init_structure.NVIC_IRQChannelCmd=ENABLE;
	nvic_init_structure.NVIC_IRQChannelPreemptionPriority=0x02;
	nvic_init_structure.NVIC_IRQChannelSubPriority=0x02;
	NVIC_Init(&nvic_init_structure);
	
	
	/*****************************************************************************************/
	
	
	USART_Init(USART1,&usart_init_structure);
	USART_Cmd(USART1,ENABLE);
}




/*****************************************************************************************************************/
/*****************************************************************************************************************/
//发送部分函数



void SERIAL_SENT_BIT(uint8_t byte)//自定义一个发送字节的函数，其中byte是8位数据，在写程序时只能用16进制的二位数，接收时选择hex则反映原始数据即16进制数值
{                          //若使用的是文本接受模式，则反应的事其对应的	ASC码表
	USART_SendData(USART1,byte);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);//USART_GetFlagStatus传输数据寄存器空标志,得到的是传输数据空标志位是否被挂起
	//如果空标志位没被挂起即为reset，则代表寄存器内部数据未被清零，及数据未完成发送
}


/*****************************************************************************************/


void SERIAL_SENT_MY_ARRY(uint8_t *arry)//自定义一个发送数组的函数，输入为数组名（即首地址）
{
	uint16_t i;
	uint16_t length;
	length = sizeof(arry)/sizeof(arry[0]);
	for(i=0;i<length;i++)
	{
		SERIAL_SENT_BIT(arry[i]);//调用之前的函数，发送单个字节
		while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
	}
}


/*****************************************************************************************/


void SERIAL_SENT_STRING(char *mystr)//这是一个发送字符串的函数需要传入一个字符数组,在USART_SendData(USART1,byte);函数中，它会自动将所属的内容转换为十六进制
{
	uint8_t i;
	for(i=0;mystr[i]!='\0';i++)//只要字符没到结尾标志，就进行输出
	{
		USART_SendData(USART1,mystr[i]);
		while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
	}

}


/*****************************************************************************************/


uint32_t square(uint16_t x,uint8_t y)//取第n位就是原数据/10的n次方
{
	uint32_t sum=1;
	while(y--)//y减到零，停止循环
	{
		sum*=x;
		}//传进y，输出则为x的y次方
	return sum;
	
}

void SERIAL_SENT_NUMBER(uint32_t NUMBER,uint8_t LENGTH)//输入一个数并将其以字符文本的形式显示出来
{
	
	uint8_t i;
	//先传入最高位，后传入低位
	//对数据除以10的n次方，得到
	for(i=0;i<LENGTH;i++)//先从最高位开始，然后依次递减
	{  //      原数据    /    第n位就除以第n-1次方然后对10取整
		SERIAL_SENT_BIT(NUMBER/square(10,LENGTH-i-1)%10+'0');//得到数据后加上一个迁移，让起变成ASC码表相应的十进制数值
	}
}

int fputc(int ch,FILE *f)
{
	SERIAL_SENT_BIT(ch);
	return ch;
}
	
void serial_printf(char *format, ...)//功能同上
{
	char string[100];
	va_list arg;
	va_start(arg,format);
	vsprintf(string,format,arg);
	va_end(arg);
	SERIAL_SENT_STRING(string);
	
	
}




/*****************************************************************************************************************/
/*****************************************************************************************************************/



//不一定会用上
uint8_t serial_getrxflage(void)		//用来判断是否接收到了数据（包），每调用一次自动清零状态位
{
	if(Serial_Rxflag==1)
	{
		Serial_Rxflag=0;
		return 1;
	}
	return 0;
}

uint8_t serial_getrxdata(void)		//直接在主函数中调用即可，无需再申明外部变量
{
	return Serial_Rxdata;

}


/*****************************************************************************************/





void USART1_IRQHandler(void)
{
	if(USART_GetFlagStatus(USART1,USART_IT_RXNE)==SET)
	{
//		Serial_Rxflag++;
		Serial_Rxdata=USART_ReceiveData(USART1);
//		SERIAL_SENT_BIT(1);
		switch(Serial_Rxdata)
		{
			case 0x10:
				Expect_Velocity=0;
				break;
			case 1:
				Expect_Velocity=300;
				break;
			case 3:
				Expect_Velocity=-300;
				break;
			case 4:
				Expect_Velocity=500;
				break;
			case 5:
				aim_turn=0;
				break;
			case 6:
				aim_turn=750;
				break;
			case 7:
				aim_turn=-750;
				break;
			case 8:
				aim_turn=1500;
				break;
			case 9:
				aim_turn=-1500;
				break;
			case 0:
				aim_turn=0;
				Expect_Velocity=0;
				break;
			default:
				break;
		}
	}
	USART_ClearITPendingBit(USART1,USART_IT_RXNE);
//	Serial_Rxflag++;
}





//void USART1_IRQHandler(void)
//{
//	if(USART_GetFlagStatus(USART1,USART_IT_RXNE)==SET)
//	{
////		Serial_Rxflag++;
//		Serial_Rxdata=USART_ReceiveData(USART1);
////		SERIAL_SENT_BIT(1);
//		switch(byte_serial_number)
//		{
//			case 0:
//				if(serial_getrxdata()==0xA5)
//				{
//					rxdata[0]=0xA5;
//					byte_serial_number=1;
//				}
//				else
//				{
//					byte_serial_number=0;
//				}
//				break;
//			case 1:
//				rxdata[1]=Serial_Rxdata;
//				byte_serial_number=2;
//					break;
//			case 2:
//				rxdata[2]=Serial_Rxdata;
//				byte_serial_number=3;
//				break;
//			case 3:
//				parity_byte=(rxdata[1]+rxdata[2])&11111111;
//				if(Serial_Rxdata==parity_byte)
//				{
//					rxdata[3]=parity_byte;
//					byte_serial_number=4;
//				}
//				else{	byte_serial_number=0; }
//				break;
//			case 4:
//				if(Serial_Rxdata==0x5A)
//				{
//					rxdata[4]=0x5A;
//					byte_serial_number=0;
//				}
//				else
//				{
//					byte_serial_number=0;
//				}
//				break;
//				
//			default:
//				break;

//		}
//	}
//	USART_ClearITPendingBit(USART1,USART_IT_RXNE);
////	Serial_Rxflag++;
//}

















