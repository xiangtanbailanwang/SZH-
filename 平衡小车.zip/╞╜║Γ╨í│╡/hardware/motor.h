#ifndef __MOTOR_H
#define __MOTOR_H
#include "stm32f10x.h"                  // Device header

void MOTOR_INIT(void);

void motor1_set_speed(int16_t speed);
void motor2_set_speed(int16_t speed);



#endif

