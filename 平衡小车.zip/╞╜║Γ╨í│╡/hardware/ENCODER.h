#ifndef __ENCODER_H
#define __ENCODER_H
#include "stm32f10x.h"  // Device header

void ENCODER_INIT(void);
int16_t ENCODER_GET(void);
extern int16_t encoder_speed1;
extern int16_t encoder_speed2;

#endif


